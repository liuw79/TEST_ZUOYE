//
//  CoverView.h
//  CarMag
//
//  Created by LIU WEI on 12-12-22.
//  Copyright (c) 2012年 LIU WEI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyImageView.h"

@interface CoverView : UIView

@property (strong, nonatomic) 

@end
