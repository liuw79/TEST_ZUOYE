//
//  MagazineShelf.m
//  CarMag
//
//  Created by LIU WEI on 12-12-22.
//  Copyright (c) 2012年 LIU WEI. All rights reserved.
//

#import "MagazineShelf.h"

@implementation MagazineShelf

@end
