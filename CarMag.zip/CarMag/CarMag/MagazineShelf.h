//
//  MagazineShelf.h
//  CarMag
//
//  Created by LIU WEI on 12-12-22.
//  Copyright (c) 2012年 LIU WEI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Magazine.h"

@interface MagazineShelf : NSObject

@property (strong, nonatomic) NSDictionary *magazineList;

@end
